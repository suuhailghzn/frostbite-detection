import json, numpy as np, torch, torch.nn.functional as F, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, glob
from PIL import Image
from train import make_model, norm
torch.set_num_threads(1); plt.rcParams.update({'font.family':'STIXGeneral','font.size':8})
d=np.load('out/base.npz',allow_pickle=True); X,y,sp=d['X'],d['y'],d['split']
m=make_model('swin'); m.load_state_dict(torch.load('out/swin.pt')); m.eval()
res=json.load(open('out/res_swin.json')); te=np.array(res['test_idx']); pt=np.array(res['test_prob']); yt=np.array(res['test_y'])
class Hook:
    def __init__(s,layer): s.a=None; s.g=None; layer.register_forward_hook(s.fwd)
    def fwd(s,mod,i,o):
        s.a=o
        if o.requires_grad: o.register_hook(lambda g:setattr(s,'g',g))
hk=Hook(m.layers[2])      # stage-3 output, 8x8 token grid (NHWC)
def gradcam(x,cls=1):
    m.zero_grad(); o=m(x); o[0,cls].backward()
    w=hk.g.mean((1,2),keepdim=True); cam=F.relu((w*hk.a).sum(-1,keepdim=True)).permute(0,3,1,2)
    cam=F.interpolate(cam,size=x.shape[-2:],mode='bilinear',align_corners=False)[0,0].detach()
    return ((cam-cam.min())/(cam.max()-cam.min()+1e-8)).numpy()
def intgrad(x,cls=1,steps=32):
    base=torch.zeros_like(x); tot=torch.zeros_like(x)
    for a in torch.linspace(1/steps,1,steps):
        xi=(base+a*(x-base)).requires_grad_(True); o=m(xi)[0,cls]; g,=torch.autograd.grad(o,xi); tot+=g
    ig=((x-base)*tot/steps)[0].abs().sum(0).detach()
    ig=F.avg_pool2d(ig[None,None],5,1,2)[0,0]; ig=ig.clamp(max=torch.quantile(ig,0.99))
    return ((ig-ig.min())/(ig.max()-ig.min()+1e-8)).numpy()
def prob(x): 
    with torch.no_grad(): return F.softmax(m(x),1)[:,1]
def del_ins(x,sal,fracs=np.linspace(0,1,11)):
    # rank 8x8 blocks (16px) by saliency; deletion: replace with zero (mean) ; insertion: reveal onto blurred baseline
    s=torch.from_numpy(sal)[None,None]; bs=F.avg_pool2d(s,16)[0,0].flatten(); order=bs.argsort(descending=True)
    dele=[];ins=[]; xb=F.avg_pool2d(x,15,1,7)*0  # zero (=dataset-mean grey) baseline for deletion / insertion
    for f in fracs:
        k=int(round(f*len(order))); mask=torch.zeros(64); mask[order[:k]]=1
        M=F.interpolate(mask.view(1,1,8,8),size=128,mode='nearest')
        dele.append(prob(x*(1-M)).item()); ins.append(prob(xb*(1-M)+x*M).item())
    return np.array(dele),np.array(ins)
# --- quantitative faithfulness on correctly-classified frostbite test images
rng=np.random.RandomState(0); idx_tp=[i for i,(p,l) in enumerate(zip(pt,yt)) if l==1 and p>=0.5]
fr=np.linspace(0,1,11); R={'Grad-CAM':[[],[]],'Integrated Gradients':[[],[]],'Random':[[],[]]}
for i in idx_tp:
    x=norm(torch.from_numpy(X[te[i]]).permute(2,0,1)[None])
    for name,sal in [('Grad-CAM',gradcam(x)),('Integrated Gradients',intgrad(x,steps=16)),('Random',rng.rand(128,128))]:
        dl,ins=del_ins(x,sal); R[name][0].append(dl); R[name][1].append(ins)
auc=lambda v:float(np.trapezoid(v,fr))
summary={k:dict(deletion_auc=auc(np.mean(v[0],0)),insertion_auc=auc(np.mean(v[1],0))) for k,v in R.items()}
summary['n_images']=len(idx_tp); json.dump(summary,open('out/xai_summary.json','w'),indent=1); print(summary)
fig,ax=plt.subplots(1,2,figsize=(7.0,2.6)); C={'Grad-CAM':'#c0392b','Integrated Gradients':'#2b5c8a','Random':'gray'}
for k,v in R.items():
    for a,j in zip(ax,(0,1)):
        mu=np.mean(v[j],0); sd=np.std(v[j],0)/np.sqrt(len(v[j])); a.plot(fr*100,mu,color=C[k],lw=1.5,label=f'{k} (AUC={auc(mu):.3f})'); a.fill_between(fr*100,mu-sd,mu+sd,color=C[k],alpha=.15)
ax[0].set_title('(a) Deletion (lower is better)',fontsize=9); ax[1].set_title('(b) Insertion (higher is better)',fontsize=9)
for a in ax: a.set_xlabel('Image area modified (%)'); a.set_ylabel('P(frostbite)'); a.legend(frameon=False,fontsize=7); a.spines[['top','right']].set_visible(False); a.grid(alpha=.25,lw=.4)
plt.tight_layout(); plt.savefig('figs/fig_faith.png',dpi=300); plt.close()
# --- qualitative panels
def overlay(img,cam,a=0.5):
    cm=plt.get_cmap('jet')(cam)[...,:3]; return np.clip((1-a)*img/255+a*cm,0,1)
def panel(items,fn,title_fn):
    fig,ax=plt.subplots(len(items),4,figsize=(6.4,1.62*len(items)))
    for r,(img,lab,p) in enumerate(items):
        x=norm(torch.from_numpy(img).permute(2,0,1)[None]); gc=gradcam(x); ig=intgrad(x)
        ax[r,0].imshow(img); ax[r,1].imshow(overlay(img,gc)); ax[r,2].imshow(ig,cmap='inferno'); 
        mask=np.where(gc[...,None]>0.5,img,img*0.25).astype(np.uint8); ax[r,3].imshow(mask)
        ax[r,0].set_ylabel(title_fn(lab,p),fontsize=7)
        for a in ax[r]: a.set_xticks([]); a.set_yticks([])
    for c,t in enumerate(['Input','Grad-CAM','Integrated Gradients','Top Grad-CAM region']): ax[0,c].set_title(t,fontsize=8)
    plt.tight_layout(); plt.savefig(fn,dpi=300); plt.close()
tf=lambda l,p:f'{"Frostbite" if l else "Normal"}\nP(frost.)={p:.2f}'
tp=[i for i in idx_tp if pt[i]>0.9][:3]; tn=[i for i,(p,l) in enumerate(zip(pt,yt)) if l==0 and p<0.1][:2]
panel([(X[te[i]],yt[i],pt[i]) for i in tp+tn],'figs/fig_xai_main.png',tf)
wrong=[i for i,(p,l) in enumerate(zip(pt,yt)) if (p>=.5)!=(l==1)]
if wrong: panel([(X[te[i]],yt[i],pt[i]) for i in wrong[:4]],'figs/fig_xai_err.png',lambda l,p:f'True: {"Frostbite" if l else "Normal"}\nP(frost.)={p:.2f}')
json.dump(dict(n_wrong=len(wrong)),open('out/xai_err.json','w'))
# external 5 images
ext=sorted(glob.glob('frostbite_dataset/test/*')); items=[]
for f in ext:
    im=np.asarray(Image.open(f).convert('RGB').resize((128,128),Image.BICUBIC)); p=prob(norm(torch.from_numpy(im).permute(2,0,1)[None])).item()
    items.append((im,1 if 'bite' in f.split('/')[-1] else 0,p)); print(f,p)
panel(items,'figs/fig_xai_ext.png',lambda l,p:f'Label: {"Frostbite" if l else "Normal"}\nP(frost.)={p:.2f}')
