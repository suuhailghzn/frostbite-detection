import sys, json, time, math, numpy as np, torch, torch.nn as nn, torch.nn.functional as F, timm
from timm.models.swin_transformer import SwinTransformer
import torchvision.transforms.v2 as T
from torchvision.transforms.v2 import functional as TF
torch.set_num_threads(1)
MEAN=torch.tensor([0.485,0.456,0.406]).view(1,3,1,1); STD=torch.tensor([0.229,0.224,0.225]).view(1,3,1,1)
def make_model(name):
    if name.startswith('swin'):
        return SwinTransformer(img_size=128,patch_size=4,window_size=4,embed_dim=48,depths=(2,2,4,2),num_heads=(2,4,8,16),num_classes=2,drop_path_rate=0.1)
    if name=='resnet18': return timm.create_model('resnet18',pretrained=False,num_classes=2)
    if name=='vit': return timm.create_model('vit_tiny_patch16_224',pretrained=False,num_classes=2,img_size=128)
AUG=T.Compose([T.RandomResizedCrop(128,scale=(0.6,1.0),ratio=(0.8,1.25),antialias=True),T.RandomHorizontalFlip(),
  T.RandomRotation(25),T.ColorJitter(0.3,0.3,0.3,0.05),T.RandomApply([T.GaussianBlur(5,(0.1,1.5))],p=0.3),
  T.RandomPerspective(0.2,p=0.3)])
def expand(X,y,per_class,seed):
    g=torch.Generator().manual_seed(seed); torch.manual_seed(seed)
    Xo=[];yo=[]
    for c in (0,1):
        idx=np.where(y==c)[0]
        xs=[torch.from_numpy(X[i]).permute(2,0,1) for i in idx]
        out=list(xs)                       # keep all originals
        k=0
        while len(out)<per_class:
            out.append(AUG(xs[k%len(xs)])); k+=1
        Xo+=out; yo+=[c]*len(out)
    return torch.stack(Xo),torch.tensor(yo)
def norm(x): return ((x.float()/255)-MEAN)/STD
def evaluate(m,X,y,bs=64):
    m.eval(); P=[]; L=0
    with torch.no_grad():
        for i in range(0,len(X),bs):
            o=m(norm(X[i:i+bs])); P.append(F.softmax(o,1)); L+=F.cross_entropy(o,y[i:i+bs],reduction='sum').item()
    P=torch.cat(P); return P, L/len(X), (P.argmax(1)==y).float().mean().item()
def main(name,aug,epochs=20,seed=42):
    torch.manual_seed(seed); np.random.seed(seed)
    d=np.load('out/base.npz',allow_pickle=True); X,y,sp=d['X'],d['y'],d['split']
    tr,va,te=[np.where(sp==s)[0] for s in (0,1,2)]
    if aug: Xt,yt=expand(X[tr],y[tr],600,seed)
    else: Xt,yt=torch.from_numpy(X[tr]).permute(0,3,1,2),torch.from_numpy(y[tr])
    Xv=torch.from_numpy(X[va]).permute(0,3,1,2); yv=torch.from_numpy(y[va])
    Xe=torch.from_numpy(X[te]).permute(0,3,1,2); ye=torch.from_numpy(y[te])
    print(name,'aug',aug,'train',len(Xt),'counts',torch.bincount(yt).tolist(),flush=True)
    m=make_model(name); bs=32; steps=epochs*math.ceil(len(Xt)/bs); warm=2*math.ceil(len(Xt)/bs)
    lr=5e-4 if name!='resnet18' else 2e-3
    opt=torch.optim.AdamW(m.parameters(),lr=lr,weight_decay=0.05)
    sch=torch.optim.lr_scheduler.LambdaLR(opt,lambda s:(s+1)/warm if s<warm else 0.5*(1+math.cos(math.pi*(s-warm)/(steps-warm))))
    hist=dict(tr_loss=[],tr_acc=[],va_loss=[],va_acc=[]); best=(-1,9e9); t0=time.time()
    tag=name+('' if aug else '_noaug')
    for ep in range(epochs):
        m.train(); perm=torch.randperm(len(Xt)); tl=0;tc=0
        for i in range(0,len(Xt),bs):
            b=perm[i:i+bs]; xb=Xt[b]; 
            flip=torch.rand(len(b))<0.5; xb=torch.where(flip.view(-1,1,1,1),xb.flip(3),xb)
            o=m(norm(xb)); loss=F.cross_entropy(o,yt[b],label_smoothing=0.1)
            opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(m.parameters(),1.0); opt.step(); sch.step()
            tl+=loss.item()*len(b); tc+=(o.argmax(1)==yt[b]).sum().item()
        _,vl,vacc=evaluate(m,Xv,yv)
        hist['tr_loss'].append(tl/len(Xt));hist['tr_acc'].append(tc/len(Xt));hist['va_loss'].append(vl);hist['va_acc'].append(vacc)
        if (vacc,-vl)>(best[0],-best[1]): best=(vacc,vl); torch.save(m.state_dict(),f'out/{tag}.pt')
        print(f'{tag} ep{ep+1} trL {tl/len(Xt):.3f} trA {tc/len(Xt):.3f} vaL {vl:.3f} vaA {vacc:.3f} t={time.time()-t0:.0f}s',flush=True)
    m.load_state_dict(torch.load(f'out/{tag}.pt'))
    P,_,acc=evaluate(m,Xe,ye)
    json.dump(dict(hist=hist,test_prob=P[:,1].tolist(),test_y=ye.tolist(),test_idx=te.tolist(),params=sum(p.numel() for p in m.parameters()),
        train_size=len(Xt),time=time.time()-t0),open(f'out/res_{tag}.json','w'))
    print(tag,'TEST ACC',acc,flush=True)
if __name__=='__main__':
    for spec in sys.argv[1:]:
        n,a=spec.split(':'); main(n,a=='1')
