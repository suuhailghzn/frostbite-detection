import json, numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score, confusion_matrix, matthews_corrcoef, precision_recall_fscore_support, accuracy_score
plt.rcParams.update({'font.family':'STIXGeneral','mathtext.fontset':'stix','font.size':9,'axes.linewidth':0.6})
M={'swin':'Swin (proposed)','swin_noaug':'Swin, no augmentation','vit':'ViT-Tiny','resnet18':'ResNet-18'}
COL={'swin':'#c0392b','swin_noaug':'#e69f00','vit':'#2b5c8a','resnet18':'#2e7d32'}
R={}; 
for k in M:
    try: R[k]=json.load(open(f'out/res_{k}.json'))
    except Exception: pass
def metrics(y,p):
    yh=(p>=0.5).astype(int); tn,fp,fn,tp=confusion_matrix(y,yh).ravel()
    pr,rc,f1,_=precision_recall_fscore_support(y,yh,average='binary',zero_division=0)
    return dict(acc=accuracy_score(y,yh),prec=pr,rec=rc,spec=tn/(tn+fp),f1=f1,auc=roc_auc_score(y,p),mcc=matthews_corrcoef(y,yh),tn=int(tn),fp=int(fp),fn=int(fn),tp=int(tp))
out={}; rng=np.random.RandomState(0)
for k,r in R.items():
    y=np.array(r['test_y']); p=np.array(r['test_prob']); m=metrics(y,p)
    B=[];A=[];F=[]
    for _ in range(2000):
        i=rng.randint(0,len(y),len(y))
        if len(set(y[i]))<2: continue
        B.append(accuracy_score(y[i],p[i]>=0.5)); A.append(roc_auc_score(y[i],p[i])); F.append(precision_recall_fscore_support(y[i],(p[i]>=.5).astype(int),average='binary',zero_division=0)[2])
    m['acc_ci']=list(np.percentile(B,[2.5,97.5])); m['auc_ci']=list(np.percentile(A,[2.5,97.5])); m['f1_ci']=list(np.percentile(F,[2.5,97.5]))
    m['params_M']=r['params']/1e6; m['train_size']=r['train_size']; m['train_time_min']=r['time']/60
    m['best_val_acc']=max(r['hist']['va_acc']); out[k]=m
json.dump(out,open('out/metrics.json','w'),indent=1)
for k,m in out.items(): print(k,{a:(round(b,4) if isinstance(b,float) else b) for a,b in m.items() if not isinstance(b,list)})
# curves
fig,ax=plt.subplots(1,2,figsize=(7.2,2.7))
for k in ['swin','vit','resnet18','swin_noaug']:
    if k not in R: continue
    h=R[k]['hist']; e=np.arange(1,len(h['va_acc'])+1)
    ax[0].plot(e,h['va_loss'],color=COL[k],label=M[k],lw=1.4); ax[1].plot(e,h['va_acc'],color=COL[k],lw=1.4,label=M[k])
ax[0].set_xlabel('Epoch'); ax[0].set_ylabel('Validation loss'); ax[1].set_xlabel('Epoch'); ax[1].set_ylabel('Validation accuracy')
ax[0].set_title('(a) Validation loss',fontsize=9); ax[1].set_title('(b) Validation accuracy',fontsize=9); ax[1].legend(frameon=False,fontsize=7.5,loc='lower right')
for a in ax: a.spines[['top','right']].set_visible(False); a.grid(alpha=.25,lw=.4)
plt.tight_layout(); plt.savefig('figs/fig_curves.png',dpi=300); plt.close()
if 'swin' in R:
    h=R['swin']['hist']; e=np.arange(1,len(h['va_acc'])+1)
    fig,ax=plt.subplots(1,2,figsize=(7.2,2.5))
    ax[0].plot(e,h['tr_loss'],'#2b5c8a',label='Train'); ax[0].plot(e,h['va_loss'],'#c0392b',label='Validation'); ax[0].set_ylabel('Loss'); ax[0].set_title('(a) Loss',fontsize=9)
    ax[1].plot(e,h['tr_acc'],'#2b5c8a',label='Train'); ax[1].plot(e,h['va_acc'],'#c0392b',label='Validation'); ax[1].set_ylabel('Accuracy'); ax[1].set_title('(b) Accuracy',fontsize=9)
    for a in ax: a.set_xlabel('Epoch'); a.spines[['top','right']].set_visible(False); a.grid(alpha=.25,lw=.4); a.legend(frameon=False,fontsize=8)
    plt.tight_layout(); plt.savefig('figs/fig_swin_curves.png',dpi=300); plt.close()
# ROC
fig,ax=plt.subplots(figsize=(3.4,3.1))
for k in ['swin','vit','resnet18','swin_noaug']:
    if k not in R: continue
    y=np.array(R[k]['test_y']); p=np.array(R[k]['test_prob']); f,t,_=roc_curve(y,p)
    ax.plot(f,t,color=COL[k],lw=1.5,label=f'{M[k]} (AUC={out[k]["auc"]:.3f})')
ax.plot([0,1],[0,1],'--',color='gray',lw=.8); ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate'); ax.legend(frameon=False,fontsize=6.5,loc='lower right'); ax.spines[['top','right']].set_visible(False); ax.grid(alpha=.25,lw=.4)
plt.tight_layout(); plt.savefig('figs/fig_roc.png',dpi=300); plt.close()
# confusion matrices
ks=[k for k in ['swin','swin_noaug','vit','resnet18'] if k in R]
fig,ax=plt.subplots(1,len(ks),figsize=(1.9*len(ks),2.2))
ax=np.atleast_1d(ax)
for a,k in zip(ax,ks):
    m=out[k]; cm=np.array([[m['tn'],m['fp']],[m['fn'],m['tp']]]); a.imshow(cm,cmap='Blues',vmin=0,vmax=cm.sum(1).max())
    for i in range(2):
        for j in range(2): a.text(j,i,cm[i,j],ha='center',va='center',color='white' if cm[i,j]>cm.max()*.55 else 'black',fontsize=11)
    a.set_xticks([0,1]); a.set_yticks([0,1]); a.set_xticklabels(['Normal','Frost.'],fontsize=7.5); a.set_yticklabels(['Normal','Frost.'],fontsize=7.5,rotation=90,va='center'); a.set_title(M[k].replace(' (proposed)',''),fontsize=8)
    a.set_xlabel('Predicted',fontsize=8); 
ax[0].set_ylabel('True',fontsize=8)
plt.tight_layout(); plt.savefig('figs/fig_cm.png',dpi=300); plt.close()
