"""Pretrained Swin-T (ImageNet) frostbite classifier -- run on a Kaggle/Colab GPU.
Dataset layout: frostbite_dataset/{bite,hand}/*.jpg   (bite = frostbite = class 1)
pip install timm torch torchvision scikit-learn imagehash pillow
"""
import glob, random, numpy as np, torch, torch.nn as nn, torch.nn.functional as F, timm, imagehash
from PIL import Image
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import classification_report, roc_auc_score
import torchvision.transforms as T
SEED=42; random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
dev='cuda' if torch.cuda.is_available() else 'cpu'
files=[];y=[]
for c,l in (('hand',0),('bite',1)):
    for f in sorted(glob.glob(f'frostbite_dataset/{c}/*')): files.append(f); y.append(l)
y=np.array(y)
# near-duplicate groups (union-find on dHash, flip-invariant) -> leakage-aware split
H=[(imagehash.dhash(Image.open(f).convert('RGB')),imagehash.dhash(Image.open(f).convert('RGB').transpose(Image.FLIP_LEFT_RIGHT))) for f in files]
par=list(range(len(files)))
def find(a):
    while par[a]!=a: par[a]=par[par[a]]; a=par[a]
    return a
for i in range(len(files)):
    for j in range(i+1,len(files)):
        if y[i]==y[j] and min(H[i][0]-H[j][0],H[i][0]-H[j][1])<=6: par[find(i)]=find(j)
g=np.array([find(i) for i in range(len(files))])
tr_val,te=next(GroupShuffleSplit(1,test_size=0.15,random_state=SEED).split(files,y,g))
tr,va=next(GroupShuffleSplit(1,test_size=0.18,random_state=SEED).split(tr_val,y[tr_val],g[tr_val])); tr,va=tr_val[tr],tr_val[va]
norm=T.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
train_tf=T.Compose([T.RandomResizedCrop(224,scale=(0.6,1)),T.RandomHorizontalFlip(),T.RandomRotation(25),T.ColorJitter(.3,.3,.3,.05),
    T.RandomApply([T.GaussianBlur(5,(0.1,1.5))],p=.3),T.RandomPerspective(.2,p=.3),T.ToTensor(),norm])
eval_tf=T.Compose([T.Resize((224,224)),T.ToTensor(),norm])
class DS(torch.utils.data.Dataset):
    def __init__(s,idx,tf,rep=1): s.idx=list(idx)*rep; s.tf=tf
    def __len__(s): return len(s.idx)
    def __getitem__(s,k): i=s.idx[k]; return s.tf(Image.open(files[i]).convert('RGB')),int(y[i])
rep=3  # offline-style expansion: each epoch sees 3 random augmentations of every training image
dl=lambda ds,sh:torch.utils.data.DataLoader(ds,batch_size=32,shuffle=sh,num_workers=2)
Ltr,Lva,Lte=dl(DS(tr,train_tf,rep),True),dl(DS(va,eval_tf),False),dl(DS(te,eval_tf),False)
m=timm.create_model('swin_tiny_patch4_window7_224',pretrained=True,num_classes=2,drop_path_rate=0.2).to(dev)
E=15; opt=torch.optim.AdamW(m.parameters(),lr=1e-4,weight_decay=0.05)
sch=torch.optim.lr_scheduler.OneCycleLR(opt,1e-4,total_steps=E*len(Ltr),pct_start=0.1)
def run(L):
    m.eval(); P=[];Y=[]
    with torch.no_grad():
        for x,t in L: P.append(F.softmax(m(x.to(dev)),1)[:,1].cpu()); Y.append(t)
    return torch.cat(P).numpy(),torch.cat(Y).numpy()
best=0
for ep in range(E):
    m.train()
    for x,t in Ltr:
        loss=F.cross_entropy(m(x.to(dev)),t.to(dev),label_smoothing=0.1); opt.zero_grad(); loss.backward(); opt.step(); sch.step()
    p,t=run(Lva); acc=((p>.5)==t).mean(); print(ep+1,'val acc',acc)
    if acc>=best: best=acc; torch.save(m.state_dict(),'swin_t_best.pt')
m.load_state_dict(torch.load('swin_t_best.pt')); p,t=run(Lte)
print(classification_report(t,p>.5,target_names=['normal','frostbite'],digits=4)); print('AUC',roc_auc_score(t,p))
