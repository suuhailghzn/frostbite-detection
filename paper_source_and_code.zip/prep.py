import glob, numpy as np, json, random
from PIL import Image, ImageOps
random.seed(42); np.random.seed(42)
CL={'hand':0,'bite':1}   # 0 = normal hand, 1 = frostbite
def dh(im):
    g=np.asarray(im.convert('L').resize((9,8),Image.LANCZOS),dtype=np.float32)
    return (g[:,1:]>g[:,:-1]).flatten()
files=[];labels=[]
for c,l in CL.items():
    for f in sorted(glob.glob(f'frostbite_dataset/{c}/*')): files.append(f);labels.append(l)
labels=np.array(labels)
H=[];
for f in files:
    im=Image.open(f).convert('RGB'); H.append((dh(im),dh(ImageOps.mirror(im))))
n=len(files); par=list(range(n))
def find(a):
    while par[a]!=a: par[a]=par[par[a]]; a=par[a]
    return a
TH=6
for i in range(n):
    for j in range(i+1,n):
        if labels[i]!=labels[j]: continue
        d=min((H[i][0]!=H[j][0]).sum(),(H[i][0]!=H[j][1]).sum())
        if d<=TH: par[find(i)]=find(j)
g=np.array([find(i) for i in range(n)])
ug,inv=np.unique(g,return_inverse=True)
print('images',n,'groups',len(ug),'largest group',np.bincount(inv).max())
# group-aware stratified split 70/15/15
rng=np.random.RandomState(42)
split=np.zeros(n,dtype=int) # 0 train 1 val 2 test
for l in (0,1):
    gl=np.unique(inv[labels==l]); rng.shuffle(gl)
    sizes={k:(inv==k).sum() for k in gl}
    tot=sum(sizes.values()); acc=0
    for k in gl:
        frac=acc/tot
        s=0 if frac<0.70 else (1 if frac<0.85 else 2)
        split[inv==k]=s; acc+=sizes[k]
for s,nm in enumerate(['train','val','test']):
    print(nm,[(int(((split==s)&(labels==l)).sum())) for l in (0,1)])
S=128
X=np.stack([np.asarray(Image.open(f).convert('RGB').resize((S,S),Image.BICUBIC)) for f in files])
np.savez_compressed('out/base.npz',X=X,y=labels,split=split,group=inv,files=np.array(files))
json.dump({'n':n,'groups':int(len(ug)),'thr':TH},open('out/groups.json','w'))
