import numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
import torch, torchvision.transforms.v2 as T
plt.rcParams.update({'font.family':'STIXGeneral','mathtext.fontset':'stix','font.size':9,'axes.linewidth':0.6})
d=np.load('out/base.npz',allow_pickle=True); X,y,sp=d['X'],d['y'],d['split']
C0,C1,C2,C3='#2b5c8a','#c0392b','#e8eef5','#f6e3df'
rng=np.random.RandomState(7)
# Fig1 dataset samples
fig,ax=plt.subplots(2,6,figsize=(7.2,2.8))
for r,c in enumerate((1,0)):
    idx=rng.choice(np.where(y==c)[0],6,replace=False)
    for k,i in enumerate(idx):
        ax[r,k].imshow(X[i]); ax[r,k].axis('off')
    ax[r,0].set_title(['Normal hand','Frostbite'][c==1] ,loc='left',fontsize=9,color=[C0,C1][c==1],fontweight='bold')
plt.tight_layout(pad=0.4); plt.savefig('figs/fig_samples.png',dpi=300); plt.close()
# Fig2 distribution
fig,ax=plt.subplots(1,2,figsize=(7.0,2.5))
labs=['Train','Val','Test']; w=0.36; xs=np.arange(3)
n0=[((sp==s)&(y==0)).sum() for s in range(3)]; n1=[((sp==s)&(y==1)).sum() for s in range(3)]
ax[0].bar(xs-w/2,n0,w,color=C0,label='Normal'); ax[0].bar(xs+w/2,n1,w,color=C1,label='Frostbite')
for i in range(3): ax[0].text(xs[i]-w/2,n0[i]+3,n0[i],ha='center',fontsize=8); ax[0].text(xs[i]+w/2,n1[i]+3,n1[i],ha='center',fontsize=8)
ax[0].set_xticks(xs); ax[0].set_xticklabels(labs); ax[0].set_ylabel('Images'); ax[0].legend(frameon=False); ax[0].set_title('(a) Original split (group-aware)',fontsize=9)
ax[1].bar(['Train\n(original)','Train\n(augmented)'],[n0[0],600],w*1.6,color=C0); ax[1].bar(['Train\n(original)','Train\n(augmented)'],[n1[0],600],w*1.6,bottom=[n0[0],600],color=C1)
ax[1].text(0,n0[0]+n1[0]+15,f'{n0[0]+n1[0]}',ha='center'); ax[1].text(1,1215,'1200',ha='center'); ax[1].set_ylim(0,1400)
ax[1].set_title('(b) Effect of augmentation on training set',fontsize=9); ax[1].set_ylabel('Images')
for a in ax: a.spines[['top','right']].set_visible(False)
plt.tight_layout(); plt.savefig('figs/fig_dist.png',dpi=300); plt.close()
# Fig3 augmentation examples
from train import AUG
torch.manual_seed(3)
i=np.where((y==1)&(sp==0))[0][12]; src=torch.from_numpy(X[i]).permute(2,0,1)
fig,ax=plt.subplots(1,8,figsize=(7.2,1.2))
ax[0].imshow(X[i]); ax[0].set_title('Original',fontsize=8)
for k in range(1,8): ax[k].imshow(AUG(src).permute(1,2,0).numpy()); ax[k].set_title(f'Aug. {k}',fontsize=8)
for a in ax: a.axis('off')
plt.tight_layout(pad=0.3); plt.savefig('figs/fig_aug.png',dpi=300); plt.close()
# helpers
def box(ax,x,y,w,h,t,fc=C2,ec=C0,fs=8,bold=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.01,rounding_size=0.08',fc=fc,ec=ec,lw=0.9))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,fontweight='bold' if bold else 'normal')
def arr(ax,a,b,c='#333'): ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=9,lw=0.9,color=c))
# Fig4 pipeline
fig,ax=plt.subplots(figsize=(7.2,2.6)); ax.set_xlim(0,14.4); ax.set_ylim(0,5.2); ax.axis('off')
steps=[('Kaggle frostbite\ndataset\n(550 images)',0.1,2.0),('Pre-processing\nresize 128×128\nnear-duplicate\ngrouping',2.4,2.0),('Group-aware\nsplit\n70 / 15 / 15',4.7,2.0),('Offline + online\naugmentation\n(train only)',7.0,2.0),('Swin\nTransformer\nclassifier',9.3,2.0),('Evaluation\nAcc, F1, AUC,\nROC',11.6,3.4)]
for t,x,yy in steps:
    box(ax,x,yy,2.0,1.5,t,fc=C3 if 'Swin' in t else C2,ec=C1 if 'Swin' in t else C0,bold='Swin' in t)
box(ax,11.6,0.5,2.0,1.5,'Explainable AI\nGrad-CAM,\nIntegrated Grad.,\nDeletion test',fc='#e6f2e6',ec='#2e7d32')
for a,b in [(2.1,2.4),(4.4,4.7),(6.7,7.0),(9.0,9.3)]: arr(ax,(a,2.75),(b,2.75))
arr(ax,(11.3,3.0),(11.6,4.0)); arr(ax,(11.3,2.5),(11.6,1.4))
ax.text(7.2,5.0,'Proposed frostbite detection framework',ha='center',fontsize=10,fontweight='bold')
plt.savefig('figs/fig_pipeline.png',dpi=300,bbox_inches='tight'); plt.close()
# Fig5 Swin architecture
fig=plt.figure(figsize=(7.2,3.6)); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,14.4); ax.set_ylim(0,7.2); ax.axis('off')
ax.imshow(X[np.where(y==1)[0][3]],extent=(0.1,1.5,3.2,4.6))
ax.text(0.8,2.9,'Input\nH×W×3',ha='center',va='top',fontsize=7.5)
st=[('Patch\nPartition\n+ Linear\nEmbed',1.9,1.5,'C'),('Stage 1\nSwin Block ×2\nH/4×W/4×C',3.7,1.7,'S'),('Stage 2\nMerge+Block ×2\nH/8×W/8×2C',5.7,1.7,'S'),('Stage 3\nMerge+Block ×4\nH/16×W/16×4C',7.7,1.7,'S'),('Stage 4\nMerge+Block ×2\nH/32×W/32×8C',9.7,1.7,'S'),('LN + GAP\nLinear\nSoftmax',11.7,1.5,'C')]
for t,x,w,k in st: box(ax,x,3.0,w,1.9,t,fc=C3 if k=='S' else C2,ec=C1 if k=='S' else C0,fs=7)
xs=[1.5,3.4,5.4,7.4,9.4,11.4,13.2]
for a,b in [(1.5,1.9),(3.4,3.7),(5.4,5.7),(7.4,7.7),(9.4,9.7),(11.4,11.7)]: arr(ax,(a,3.95),(b,3.95))
box(ax,13.3,3.4,1.0,1.1,'Frostbite\nvs\nNormal',fc='#e6f2e6',ec='#2e7d32',fs=7); arr(ax,(13.2,3.95),(13.3,3.95))
ax.text(7.2,7.0,'Hierarchical Swin Transformer backbone',ha='center',fontsize=10,fontweight='bold')
# Swin block detail
ax.text(3.7,2.45,'Two successive Swin Transformer blocks',fontsize=8.5,fontweight='bold')
bx=[('LN',4.0),('W-MSA',4.9),('+',5.9),('LN',6.5),('MLP',7.3),('+',8.1),('LN',8.7),('SW-MSA',9.5),('+',10.7),('LN',11.3),('MLP',12.1),('+',12.9)]
for t,x in bx:
    if t=='+': ax.add_patch(plt.Circle((x+0.2,1.3),0.2,fc='white',ec='#333',lw=0.8)); ax.text(x+0.2,1.3,'+',ha='center',va='center',fontsize=8)
    else: box(ax,x,1.0,0.8 if t!='SW-MSA' else 1.1,0.6,t,fs=7,fc=C3 if 'MSA' in t else C2,ec=C1 if 'MSA' in t else C0)
for a,b in [(3.7,4.0),(4.8,4.9),(5.7,5.9),(6.1,6.5),(7.2,7.3),(8.1,8.3),(8.5,8.7),(9.5,9.5),(10.6,10.7),(10.9,11.3),(12.0,12.1),(12.9,12.9)]: pass
pts=[(3.7,1.3),(4.0,1.3)]
for x0,x1 in [(3.8,4.0),(4.8,4.9),(5.7,5.7),(6.1,6.5),(7.2,7.3),(8.1,8.3),(8.5,8.7),(9.5,9.5),(10.6,10.9),(11.1,11.3),(12.0,12.1),(12.9,12.9)]: pass
for x0,x1 in [(3.8,4.0),(4.8,4.9),(5.8,6.5),(7.1,7.3),(8.1,8.7),(9.5,9.5)]: arr(ax,(x0,1.3),(x1,1.3))
ax.text(8.0,0.45,r'$\hat z^{l}=\mathrm{W\!-\!MSA}(\mathrm{LN}(z^{l-1}))+z^{l-1}$,   $z^{l}=\mathrm{MLP}(\mathrm{LN}(\hat z^{l}))+\hat z^{l}$ (then the same with SW-MSA)',ha='center',fontsize=7.5)
plt.savefig('figs/fig_swin.png',dpi=300); plt.close()
# Fig6 shifted window
fig,ax=plt.subplots(1,2,figsize=(5.2,2.4))
for k,(sh,tt) in enumerate([(0,'Layer $l$: regular windows'),(2,'Layer $l{+}1$: shifted windows')]):
    a=ax[k]; a.set_xlim(0,8); a.set_ylim(0,8); a.set_aspect('equal'); a.axis('off'); a.set_title(tt,fontsize=8.5)
    for i in range(8):
        for j in range(8): a.add_patch(Rectangle((i,j),1,1,fc='white',ec='#bbb',lw=0.4))
    if sh==0:
        for i in (0,4):
            for j in (0,4): a.add_patch(Rectangle((i,j),4,4,fc='none',ec=C1,lw=1.6))
    else:
        for (x0,y0,w,h) in [(0,0,2,2),(2,0,4,2),(6,0,2,2),(0,2,2,4),(2,2,4,4),(6,2,2,4),(0,6,2,2),(2,6,4,2),(6,6,2,2)]: a.add_patch(Rectangle((x0,y0),w,h,fc='none',ec=C0,lw=1.6))
plt.tight_layout(); plt.savefig('figs/fig_shift.png',dpi=300); plt.close()
print('ok')
