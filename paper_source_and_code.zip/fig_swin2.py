import numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({'font.family':'STIXGeneral','mathtext.fontset':'stix'})
d=np.load('out/base.npz',allow_pickle=True); X,y=d['X'],d['y']
C0,C1,C2,C3='#2b5c8a','#c0392b','#e8eef5','#f6e3df'
def box(ax,x,yy,w,h,t,fc=C2,ec=C0,fs=7.5,bold=False):
    ax.add_patch(FancyBboxPatch((x,yy),w,h,boxstyle='round,pad=0.0,rounding_size=0.08',fc=fc,ec=ec,lw=0.9))
    ax.text(x+w/2,yy+h/2,t,ha='center',va='center',fontsize=fs,fontweight='bold' if bold else 'normal')
def arr(ax,a,b): ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=8,lw=0.9,color='#333',shrinkA=0,shrinkB=0))
fig=plt.figure(figsize=(7.2,3.5)); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,14.4); ax.set_ylim(0,7.0); ax.axis('off')
ax.text(7.2,6.7,'(a) Hierarchical Swin Transformer backbone',ha='center',fontsize=9.5,fontweight='bold')
ax.imshow(X[np.where(y==1)[0][3]],extent=(0.1,1.5,4.0,5.4)); ax.text(0.8,3.8,'Input\n$H{\\times}W{\\times}3$',ha='center',va='top',fontsize=7.5)
cols=[('Patch partition\n+ linear embed\n$\\frac{H}{4}{\\times}\\frac{W}{4}{\\times}C$',C2,C0),('Stage 1\nSwin block ×2\n$\\frac{H}{4}{\\times}\\frac{W}{4}{\\times}C$',C3,C1),('Stage 2\nMerge + block ×2\n$\\frac{H}{8}{\\times}\\frac{W}{8}{\\times}2C$',C3,C1),('Stage 3\nMerge + block ×4\n$\\frac{H}{16}{\\times}\\frac{W}{16}{\\times}4C$',C3,C1),('Stage 4\nMerge + block ×2\n$\\frac{H}{32}{\\times}\\frac{W}{32}{\\times}8C$',C3,C1),('LN + GAP\nLinear + softmax',C2,C0)]
x=1.95; w=1.75; gap=0.3
for t,fc,ec in cols:
    box(ax,x,3.9,w,1.6,t,fc,ec,fs=7); arr(ax,(x-gap,4.7),(x,4.7)); x+=w+gap
arr(ax,(1.5,4.7),(1.65,4.7))
ax.text(7.2,3.2,'(b) Two successive Swin Transformer blocks',ha='center',fontsize=9.5,fontweight='bold')
seq=['LN','W-MSA','+','LN','MLP','+','LN','SW-MSA','+','LN','MLP','+']
wd=lambda t:0.5 if t=='+' else (1.15 if 'MSA' in t else 0.8)
tot=sum(wd(t) for t in seq)+0.45*(len(seq)-1); x=(14.4-tot)/2; ax.text(x-0.2,1.95,'$z^{l-1}$',ha='right',va='center',fontsize=8)
for k,t in enumerate(seq):
    w=wd(t)
    if t=='+':
        ax.add_patch(plt.Circle((x+w/2,1.95),0.22,fc='white',ec='#333',lw=0.8)); ax.text(x+w/2,1.95,'+',ha='center',va='center',fontsize=9)
    else: box(ax,x,1.65,w,0.6,t,fc=C3 if 'MSA' in t else C2,ec=C1 if 'MSA' in t else C0,fs=7.5)
    if k<len(seq)-1: arr(ax,(x+w+(0 if t!='+' else -0.06),1.95),(x+w+0.45,1.95))
    x+=w+0.45
ax.text(7.2,0.85,r'$\hat{z}^{l}=\mathrm{W\text{-}MSA}(\mathrm{LN}(z^{l-1}))+z^{l-1},\quad z^{l}=\mathrm{MLP}(\mathrm{LN}(\hat{z}^{l}))+\hat{z}^{l}$',ha='center',fontsize=8)
ax.text(7.2,0.3,r'$\hat{z}^{l+1}=\mathrm{SW\text{-}MSA}(\mathrm{LN}(z^{l}))+z^{l},\quad z^{l+1}=\mathrm{MLP}(\mathrm{LN}(\hat{z}^{l+1}))+\hat{z}^{l+1}$',ha='center',fontsize=8)
plt.savefig('figs/fig_swin.png',dpi=300); plt.close()
